import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

public class StubDriver {

  public static void main(String[] args) throws Exception {

    /*
     * Validate that two arguments were passed from the command line.
     */
    if (args.length != 2) {
      System.out.printf("Usage: StubDriver <input dir> <output dir>\n");
      System.exit(-1);
    }
    
    /*
     * Instantiate a Job object for your job's configuration. 
     */
    Configuration conf = new Configuration();
    Job job = Job.getInstance(conf, "WordCount");
    
    /*
     * Specify the jar file that contains your driver, mapper, and reducer.
     * Hadoop will transfer this jar file to nodes in your cluster running 
     * mapper and reducer tasks.
     */
    job.setJarByClass(StubDriver.class);
    job.setMapperClass(StubMapper.class);
    job.setReducerClass(StubReducer.class);
    
    job.setMapOutputKeyClass(Text.class);
    job.setMapOutputValueClass(Text.class);
    job.setOutputKeyClass(Text.class);
    job.setOutputValueClass(Text.class);
    job.setInputFormatClass(TextInputFormat.class);
    job.setOutputFormatClass(TextOutputFormat.class);
    
    FileInputFormat.addInputPath(job, new Path(args[0]));
    FileOutputFormat.setOutputPath(job, new Path(args[1]));
    /*
     * Specify an easily-decipherable name for the job.
     * This job name will appear in reports and logs.
     */
    job.setJobName("Stub Driver");

    /*
     * TODO implement
     */
    
    /*
     * Start the MapReduce job and wait for it to finish.
     * If it finishes successfully, return 0. If not, return 1.
     */
    boolean success = job.waitForCompletion(true);
    System.exit(success ? 0 : 1);
  }
}

public class StubMapper extends Mapper<LongWritable, Text, Text, Text>{

  @Override
  public void map(LongWritable key, Text value, Context context)
	  throws IOException, InterruptedException{

      String stockanddate;
      String volume;
      
      String[] tuple = value.toString().split("\\n");
      try{
          for(int i=0;i<tuple.length; i++){
              JSONObject obj = new JSONObject(tuple[i]);
              stockanddate = obj.getString("stockAndDate");
              volume = obj.getString("volumePrice");
              String ivol = String.valueOf(volume.charAt(0));
              String[] parts = stockanddate.split("-");
              String sad = parts[0];
              ivol= "$" + ivol + " billion " + parts[1] +" quarter";
              context.write(new Text(sad), new Text(ivol));
          }
      }catch(JSONException e){
          e.printStackTrace();
      }
  }
}

public class StubReducer extends Reducer<Text,Text,Text,Text>{

  @Override
  public void reduce(Text key, Iterable<Text> values, Context context) 
		  throws IOException, InterruptedException{

      try{
    	  
          JSONObject obj = new JSONObject();            
          JSONArray ja = new JSONArray();
          
          for(Text val : values){
              JSONObject jo = new JSONObject().put("volumePrice", val.toString());
              ja.put(jo);
          }
          context.write(new Text(key.toString()), new Text(ja.toString()));
          
      }catch(JSONException e){
          e.printStackTrace();
      }
  }
}