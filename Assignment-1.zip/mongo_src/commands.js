//mongoimport -d mydb1 -c djis --type csv --file E:/djindex.csv -�headerline

var map4 = function(){ 
	var key = this.stock+"-"+this.quarter;
	var value = {
		date1: this.date,
		quarter1: this.quarter,
		open1: this.open, 
		high1: this.high,
		low1: this.low, 
		close1: this.close,
		volume1: this.volume,
		next_weeks_open1: this.next_weeks_open,
		next_weeks_close1: this.next_weeks_close 
	};

	emit(key,value);
}

var reduce4 = function(key,values){ 
	var final_val = {
	quarter: 0, 
	volumePrice: 0, 
	closingPrice: 0,
	stockAndDate: key, 
	dailyAvg: 0,
	weekAvg: 0,
	twoWeekAvg: 0
	}

	for (var i = 1; i < values.length; i++) {
		final_val.quarter = values[i].quarter1;
		if(isNaN(values[i].close1)==false && isNaN(values[i].volume1)==false){
		final_val.volumePrice += (values[i].close1 * values[i].volume1);
		}
		final_val.closingPrice += values[i].close1; 
		final_val.stockAndDate += "-"+values[i].date1;
		final_val.dailyAvg += ( values[i].open1 + values[i].close1 ) / 2; 
		final_val.weekAvg += ( values[i].next_weeks_open1 + values[i].next_weeks_close1 ) / 2; 
		final_val.twoWeekAvg += ( values[i].open1 + values[i].close1 + values[i].next_weeks_open1 + values[i].next_weeks_close1 ) / 4;
	} 
	final_val.volumePrice /= values.length;
	final_val.closingPrice /= values.length;
	final_val.dailyAvg /= values.length;
	final_val.weekAvg /= values.length;
	final_val.twoWeekAvg /= values.length;

	return quarter;
	return volumePrice; 
	return closingPrice;
	return stockAndDate; 
	return dailyAvg;
	return weekAvg;
	return twoWeekAvg;
}

db.djis.mapReduce( 
	map4, 
	reduce4, 
	{ out: "djis_filtered14" } 
)

//mongoexport --db mydb1 --collection djis_filtered --out e:\djis_filtered.json 